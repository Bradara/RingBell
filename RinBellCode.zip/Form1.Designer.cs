﻿namespace RingBell
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblClock = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            tboxLesson1Start1 = new TextBox();
            label9 = new Label();
            label10 = new Label();
            tboxLesson1End1 = new TextBox();
            label11 = new Label();
            cbox1break1 = new ComboBox();
            label12 = new Label();
            label13 = new Label();
            cbox1break2 = new ComboBox();
            tboxLesson1End2 = new TextBox();
            tboxLesson1Start2 = new TextBox();
            label14 = new Label();
            cbox1break3 = new ComboBox();
            tboxLesson1End3 = new TextBox();
            tboxLesson1Start3 = new TextBox();
            label15 = new Label();
            cbox1break4 = new ComboBox();
            tboxLesson1End4 = new TextBox();
            tboxLesson1Start4 = new TextBox();
            label16 = new Label();
            cbox1break5 = new ComboBox();
            tboxLesson1End5 = new TextBox();
            tboxLesson1Start5 = new TextBox();
            label17 = new Label();
            cbox1break6 = new ComboBox();
            tboxLesson1End6 = new TextBox();
            tboxLesson1Start6 = new TextBox();
            label18 = new Label();
            cbox1break7 = new ComboBox();
            tboxLesson1End7 = new TextBox();
            tboxLesson1Start7 = new TextBox();
            btnGenerateTimeTable1 = new Button();
            errorProvider1 = new ErrorProvider(components);
            label19 = new Label();
            cbox2break7 = new ComboBox();
            tboxLesson2End7 = new TextBox();
            tboxLesson2Start7 = new TextBox();
            label20 = new Label();
            cbox2break6 = new ComboBox();
            tboxLesson2End6 = new TextBox();
            tboxLesson2Start6 = new TextBox();
            label21 = new Label();
            cbox2break5 = new ComboBox();
            tboxLesson2End5 = new TextBox();
            tboxLesson2Start5 = new TextBox();
            label22 = new Label();
            cbox2break4 = new ComboBox();
            tboxLesson2End4 = new TextBox();
            tboxLesson2Start4 = new TextBox();
            label23 = new Label();
            cbox2break3 = new ComboBox();
            tboxLesson2End3 = new TextBox();
            tboxLesson2Start3 = new TextBox();
            label24 = new Label();
            cbox2break2 = new ComboBox();
            tboxLesson2End2 = new TextBox();
            tboxLesson2Start2 = new TextBox();
            label25 = new Label();
            cbox2break1 = new ComboBox();
            label26 = new Label();
            tboxLesson2End1 = new TextBox();
            label27 = new Label();
            label28 = new Label();
            tboxLesson2Start1 = new TextBox();
            label29 = new Label();
            label30 = new Label();
            label31 = new Label();
            label32 = new Label();
            label33 = new Label();
            label34 = new Label();
            label35 = new Label();
            label36 = new Label();
            cbox1Monday = new CheckBox();
            cbox1Tuesday = new CheckBox();
            cbox1Wednesday = new CheckBox();
            cbox1Thursday = new CheckBox();
            cbox1Friday = new CheckBox();
            cbox2Friday = new CheckBox();
            cbox2Thursday = new CheckBox();
            cbox2Wednesday = new CheckBox();
            cbox2Tuesday = new CheckBox();
            cbox2Monday = new CheckBox();
            toolTip1 = new ToolTip(components);
            btnGenerateTimeTable2 = new Button();
            lblInfo = new Label();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // lblClock
            // 
            lblClock.AutoSize = true;
            lblClock.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblClock.Location = new Point(860, 10);
            lblClock.Name = "lblClock";
            lblClock.Size = new Size(114, 31);
            lblClock.TabIndex = 0;
            lblClock.Text = "Часовник";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(122, 9);
            label1.Name = "label1";
            label1.Size = new Size(157, 32);
            label1.TabIndex = 1;
            label1.Text = "Първа смяна";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 128);
            label2.Name = "label2";
            label2.Size = new Size(20, 20);
            label2.TabIndex = 2;
            label2.Text = "1.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 161);
            label3.Name = "label3";
            label3.Size = new Size(20, 20);
            label3.TabIndex = 3;
            label3.Text = "2.";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 229);
            label4.Name = "label4";
            label4.Size = new Size(20, 20);
            label4.TabIndex = 4;
            label4.Text = "4.";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 196);
            label5.Name = "label5";
            label5.Size = new Size(20, 20);
            label5.TabIndex = 5;
            label5.Text = "3.";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 262);
            label6.Name = "label6";
            label6.Size = new Size(20, 20);
            label6.TabIndex = 6;
            label6.Text = "5.";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(9, 328);
            label7.Name = "label7";
            label7.Size = new Size(20, 20);
            label7.TabIndex = 7;
            label7.Text = "7.";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(9, 295);
            label8.Name = "label8";
            label8.Size = new Size(20, 20);
            label8.TabIndex = 8;
            label8.Text = "6.";
            // 
            // tboxLesson1Start1
            // 
            tboxLesson1Start1.Location = new Point(47, 125);
            tboxLesson1Start1.Name = "tboxLesson1Start1";
            tboxLesson1Start1.Size = new Size(75, 27);
            tboxLesson1Start1.TabIndex = 9;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(48, 102);
            label9.Name = "label9";
            label9.Size = new Size(61, 20);
            label9.TabIndex = 10;
            label9.Text = "Начало";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(141, 102);
            label10.Name = "label10";
            label10.Size = new Size(44, 20);
            label10.TabIndex = 11;
            label10.Text = "Край";
            // 
            // tboxLesson1End1
            // 
            tboxLesson1End1.Location = new Point(141, 125);
            tboxLesson1End1.Name = "tboxLesson1End1";
            tboxLesson1End1.Size = new Size(85, 27);
            tboxLesson1End1.TabIndex = 12;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(243, 102);
            label11.Name = "label11";
            label11.Size = new Size(96, 20);
            label11.TabIndex = 13;
            label11.Text = "Междучасие";
            // 
            // cbox1break1
            // 
            cbox1break1.FormattingEnabled = true;
            cbox1break1.Items.AddRange(new object[] { "5", "10", "20" });
            cbox1break1.Location = new Point(243, 125);
            cbox1break1.Name = "cbox1break1";
            cbox1break1.Size = new Size(68, 28);
            cbox1break1.TabIndex = 14;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(327, 128);
            label12.Name = "label12";
            label12.Size = new Size(60, 20);
            label12.TabIndex = 15;
            label12.Text = "минути";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(327, 161);
            label13.Name = "label13";
            label13.Size = new Size(60, 20);
            label13.TabIndex = 19;
            label13.Text = "минути";
            // 
            // cbox1break2
            // 
            cbox1break2.FormattingEnabled = true;
            cbox1break2.Items.AddRange(new object[] { "5", "10", "20" });
            cbox1break2.Location = new Point(243, 158);
            cbox1break2.Name = "cbox1break2";
            cbox1break2.Size = new Size(68, 28);
            cbox1break2.TabIndex = 18;
            // 
            // tboxLesson1End2
            // 
            tboxLesson1End2.Location = new Point(141, 158);
            tboxLesson1End2.Name = "tboxLesson1End2";
            tboxLesson1End2.Size = new Size(85, 27);
            tboxLesson1End2.TabIndex = 17;
            // 
            // tboxLesson1Start2
            // 
            tboxLesson1Start2.Location = new Point(47, 158);
            tboxLesson1Start2.Name = "tboxLesson1Start2";
            tboxLesson1Start2.Size = new Size(75, 27);
            tboxLesson1Start2.TabIndex = 16;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(327, 196);
            label14.Name = "label14";
            label14.Size = new Size(60, 20);
            label14.TabIndex = 23;
            label14.Text = "минути";
            // 
            // cbox1break3
            // 
            cbox1break3.FormattingEnabled = true;
            cbox1break3.Items.AddRange(new object[] { "5", "10", "20" });
            cbox1break3.Location = new Point(243, 193);
            cbox1break3.Name = "cbox1break3";
            cbox1break3.Size = new Size(68, 28);
            cbox1break3.TabIndex = 22;
            // 
            // tboxLesson1End3
            // 
            tboxLesson1End3.Location = new Point(141, 193);
            tboxLesson1End3.Name = "tboxLesson1End3";
            tboxLesson1End3.Size = new Size(85, 27);
            tboxLesson1End3.TabIndex = 21;
            // 
            // tboxLesson1Start3
            // 
            tboxLesson1Start3.Location = new Point(47, 193);
            tboxLesson1Start3.Name = "tboxLesson1Start3";
            tboxLesson1Start3.Size = new Size(75, 27);
            tboxLesson1Start3.TabIndex = 20;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(327, 229);
            label15.Name = "label15";
            label15.Size = new Size(60, 20);
            label15.TabIndex = 27;
            label15.Text = "минути";
            // 
            // cbox1break4
            // 
            cbox1break4.FormattingEnabled = true;
            cbox1break4.Items.AddRange(new object[] { "5", "10", "20" });
            cbox1break4.Location = new Point(243, 226);
            cbox1break4.Name = "cbox1break4";
            cbox1break4.Size = new Size(68, 28);
            cbox1break4.TabIndex = 26;
            // 
            // tboxLesson1End4
            // 
            tboxLesson1End4.Location = new Point(141, 226);
            tboxLesson1End4.Name = "tboxLesson1End4";
            tboxLesson1End4.Size = new Size(85, 27);
            tboxLesson1End4.TabIndex = 25;
            // 
            // tboxLesson1Start4
            // 
            tboxLesson1Start4.Location = new Point(47, 226);
            tboxLesson1Start4.Name = "tboxLesson1Start4";
            tboxLesson1Start4.Size = new Size(75, 27);
            tboxLesson1Start4.TabIndex = 24;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(327, 262);
            label16.Name = "label16";
            label16.Size = new Size(60, 20);
            label16.TabIndex = 31;
            label16.Text = "минути";
            // 
            // cbox1break5
            // 
            cbox1break5.FormattingEnabled = true;
            cbox1break5.Items.AddRange(new object[] { "5", "10", "20" });
            cbox1break5.Location = new Point(243, 259);
            cbox1break5.Name = "cbox1break5";
            cbox1break5.Size = new Size(68, 28);
            cbox1break5.TabIndex = 30;
            // 
            // tboxLesson1End5
            // 
            tboxLesson1End5.Location = new Point(141, 259);
            tboxLesson1End5.Name = "tboxLesson1End5";
            tboxLesson1End5.Size = new Size(85, 27);
            tboxLesson1End5.TabIndex = 29;
            // 
            // tboxLesson1Start5
            // 
            tboxLesson1Start5.Location = new Point(47, 259);
            tboxLesson1Start5.Name = "tboxLesson1Start5";
            tboxLesson1Start5.Size = new Size(75, 27);
            tboxLesson1Start5.TabIndex = 28;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(327, 295);
            label17.Name = "label17";
            label17.Size = new Size(60, 20);
            label17.TabIndex = 35;
            label17.Text = "минути";
            // 
            // cbox1break6
            // 
            cbox1break6.FormattingEnabled = true;
            cbox1break6.Items.AddRange(new object[] { "5", "10", "20" });
            cbox1break6.Location = new Point(243, 292);
            cbox1break6.Name = "cbox1break6";
            cbox1break6.Size = new Size(68, 28);
            cbox1break6.TabIndex = 34;
            // 
            // tboxLesson1End6
            // 
            tboxLesson1End6.Location = new Point(141, 292);
            tboxLesson1End6.Name = "tboxLesson1End6";
            tboxLesson1End6.Size = new Size(85, 27);
            tboxLesson1End6.TabIndex = 33;
            // 
            // tboxLesson1Start6
            // 
            tboxLesson1Start6.Location = new Point(47, 292);
            tboxLesson1Start6.Name = "tboxLesson1Start6";
            tboxLesson1Start6.Size = new Size(75, 27);
            tboxLesson1Start6.TabIndex = 32;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(327, 328);
            label18.Name = "label18";
            label18.Size = new Size(60, 20);
            label18.TabIndex = 39;
            label18.Text = "минути";
            // 
            // cbox1break7
            // 
            cbox1break7.FormattingEnabled = true;
            cbox1break7.Items.AddRange(new object[] { "5", "10", "20" });
            cbox1break7.Location = new Point(243, 325);
            cbox1break7.Name = "cbox1break7";
            cbox1break7.Size = new Size(68, 28);
            cbox1break7.TabIndex = 38;
            // 
            // tboxLesson1End7
            // 
            tboxLesson1End7.Location = new Point(141, 325);
            tboxLesson1End7.Name = "tboxLesson1End7";
            tboxLesson1End7.Size = new Size(85, 27);
            tboxLesson1End7.TabIndex = 37;
            // 
            // tboxLesson1Start7
            // 
            tboxLesson1Start7.Location = new Point(47, 325);
            tboxLesson1Start7.Name = "tboxLesson1Start7";
            tboxLesson1Start7.Size = new Size(75, 27);
            tboxLesson1Start7.TabIndex = 36;
            // 
            // btnGenerateTimeTable1
            // 
            btnGenerateTimeTable1.BackColor = SystemColors.ActiveCaption;
            btnGenerateTimeTable1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnGenerateTimeTable1.Location = new Point(48, 373);
            btnGenerateTimeTable1.Name = "btnGenerateTimeTable1";
            btnGenerateTimeTable1.Size = new Size(263, 72);
            btnGenerateTimeTable1.TabIndex = 40;
            btnGenerateTimeTable1.Text = "Генерирай разписание първа смяна";
            toolTip1.SetToolTip(btnGenerateTimeTable1, "За да генерирате разписание е нужно\r\nда въведете начало и край за първи час,\r\nкакто и всички междучасия.");
            btnGenerateTimeTable1.UseVisualStyleBackColor = false;
            btnGenerateTimeTable1.Click += btnGenerateTimeTable1_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(794, 328);
            label19.Name = "label19";
            label19.Size = new Size(60, 20);
            label19.TabIndex = 83;
            label19.Text = "минути";
            // 
            // cbox2break7
            // 
            cbox2break7.FormattingEnabled = true;
            cbox2break7.Items.AddRange(new object[] { "5", "10", "20" });
            cbox2break7.Location = new Point(710, 325);
            cbox2break7.Name = "cbox2break7";
            cbox2break7.Size = new Size(68, 28);
            cbox2break7.TabIndex = 82;
            // 
            // tboxLesson2End7
            // 
            tboxLesson2End7.Location = new Point(608, 325);
            tboxLesson2End7.Name = "tboxLesson2End7";
            tboxLesson2End7.Size = new Size(85, 27);
            tboxLesson2End7.TabIndex = 81;
            // 
            // tboxLesson2Start7
            // 
            tboxLesson2Start7.Location = new Point(514, 325);
            tboxLesson2Start7.Name = "tboxLesson2Start7";
            tboxLesson2Start7.Size = new Size(75, 27);
            tboxLesson2Start7.TabIndex = 80;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(794, 295);
            label20.Name = "label20";
            label20.Size = new Size(60, 20);
            label20.TabIndex = 79;
            label20.Text = "минути";
            // 
            // cbox2break6
            // 
            cbox2break6.FormattingEnabled = true;
            cbox2break6.Items.AddRange(new object[] { "5", "10", "20" });
            cbox2break6.Location = new Point(710, 292);
            cbox2break6.Name = "cbox2break6";
            cbox2break6.Size = new Size(68, 28);
            cbox2break6.TabIndex = 78;
            // 
            // tboxLesson2End6
            // 
            tboxLesson2End6.Location = new Point(608, 292);
            tboxLesson2End6.Name = "tboxLesson2End6";
            tboxLesson2End6.Size = new Size(85, 27);
            tboxLesson2End6.TabIndex = 77;
            // 
            // tboxLesson2Start6
            // 
            tboxLesson2Start6.Location = new Point(514, 292);
            tboxLesson2Start6.Name = "tboxLesson2Start6";
            tboxLesson2Start6.Size = new Size(75, 27);
            tboxLesson2Start6.TabIndex = 76;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(794, 262);
            label21.Name = "label21";
            label21.Size = new Size(60, 20);
            label21.TabIndex = 75;
            label21.Text = "минути";
            // 
            // cbox2break5
            // 
            cbox2break5.FormattingEnabled = true;
            cbox2break5.Items.AddRange(new object[] { "5", "10", "20" });
            cbox2break5.Location = new Point(710, 259);
            cbox2break5.Name = "cbox2break5";
            cbox2break5.Size = new Size(68, 28);
            cbox2break5.TabIndex = 74;
            // 
            // tboxLesson2End5
            // 
            tboxLesson2End5.Location = new Point(608, 259);
            tboxLesson2End5.Name = "tboxLesson2End5";
            tboxLesson2End5.Size = new Size(85, 27);
            tboxLesson2End5.TabIndex = 73;
            // 
            // tboxLesson2Start5
            // 
            tboxLesson2Start5.Location = new Point(514, 259);
            tboxLesson2Start5.Name = "tboxLesson2Start5";
            tboxLesson2Start5.Size = new Size(75, 27);
            tboxLesson2Start5.TabIndex = 72;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(794, 229);
            label22.Name = "label22";
            label22.Size = new Size(60, 20);
            label22.TabIndex = 71;
            label22.Text = "минути";
            // 
            // cbox2break4
            // 
            cbox2break4.FormattingEnabled = true;
            cbox2break4.Items.AddRange(new object[] { "5", "10", "20" });
            cbox2break4.Location = new Point(710, 226);
            cbox2break4.Name = "cbox2break4";
            cbox2break4.Size = new Size(68, 28);
            cbox2break4.TabIndex = 70;
            // 
            // tboxLesson2End4
            // 
            tboxLesson2End4.Location = new Point(608, 226);
            tboxLesson2End4.Name = "tboxLesson2End4";
            tboxLesson2End4.Size = new Size(85, 27);
            tboxLesson2End4.TabIndex = 69;
            // 
            // tboxLesson2Start4
            // 
            tboxLesson2Start4.Location = new Point(514, 226);
            tboxLesson2Start4.Name = "tboxLesson2Start4";
            tboxLesson2Start4.Size = new Size(75, 27);
            tboxLesson2Start4.TabIndex = 68;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(794, 196);
            label23.Name = "label23";
            label23.Size = new Size(60, 20);
            label23.TabIndex = 67;
            label23.Text = "минути";
            // 
            // cbox2break3
            // 
            cbox2break3.FormattingEnabled = true;
            cbox2break3.Items.AddRange(new object[] { "5", "10", "20" });
            cbox2break3.Location = new Point(710, 193);
            cbox2break3.Name = "cbox2break3";
            cbox2break3.Size = new Size(68, 28);
            cbox2break3.TabIndex = 66;
            // 
            // tboxLesson2End3
            // 
            tboxLesson2End3.Location = new Point(608, 193);
            tboxLesson2End3.Name = "tboxLesson2End3";
            tboxLesson2End3.Size = new Size(85, 27);
            tboxLesson2End3.TabIndex = 65;
            // 
            // tboxLesson2Start3
            // 
            tboxLesson2Start3.Location = new Point(514, 193);
            tboxLesson2Start3.Name = "tboxLesson2Start3";
            tboxLesson2Start3.Size = new Size(75, 27);
            tboxLesson2Start3.TabIndex = 64;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(794, 161);
            label24.Name = "label24";
            label24.Size = new Size(60, 20);
            label24.TabIndex = 63;
            label24.Text = "минути";
            // 
            // cbox2break2
            // 
            cbox2break2.FormattingEnabled = true;
            cbox2break2.Items.AddRange(new object[] { "5", "10", "20" });
            cbox2break2.Location = new Point(710, 158);
            cbox2break2.Name = "cbox2break2";
            cbox2break2.Size = new Size(68, 28);
            cbox2break2.TabIndex = 62;
            // 
            // tboxLesson2End2
            // 
            tboxLesson2End2.Location = new Point(608, 158);
            tboxLesson2End2.Name = "tboxLesson2End2";
            tboxLesson2End2.Size = new Size(85, 27);
            tboxLesson2End2.TabIndex = 61;
            // 
            // tboxLesson2Start2
            // 
            tboxLesson2Start2.Location = new Point(514, 158);
            tboxLesson2Start2.Name = "tboxLesson2Start2";
            tboxLesson2Start2.Size = new Size(75, 27);
            tboxLesson2Start2.TabIndex = 60;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(794, 128);
            label25.Name = "label25";
            label25.Size = new Size(60, 20);
            label25.TabIndex = 59;
            label25.Text = "минути";
            // 
            // cbox2break1
            // 
            cbox2break1.FormattingEnabled = true;
            cbox2break1.Items.AddRange(new object[] { "5", "10", "20" });
            cbox2break1.Location = new Point(710, 125);
            cbox2break1.Name = "cbox2break1";
            cbox2break1.Size = new Size(68, 28);
            cbox2break1.TabIndex = 58;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(710, 102);
            label26.Name = "label26";
            label26.Size = new Size(96, 20);
            label26.TabIndex = 57;
            label26.Text = "Междучасие";
            // 
            // tboxLesson2End1
            // 
            tboxLesson2End1.Location = new Point(608, 125);
            tboxLesson2End1.Name = "tboxLesson2End1";
            tboxLesson2End1.Size = new Size(85, 27);
            tboxLesson2End1.TabIndex = 56;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(608, 102);
            label27.Name = "label27";
            label27.Size = new Size(44, 20);
            label27.TabIndex = 55;
            label27.Text = "Край";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(515, 102);
            label28.Name = "label28";
            label28.Size = new Size(61, 20);
            label28.TabIndex = 54;
            label28.Text = "Начало";
            // 
            // tboxLesson2Start1
            // 
            tboxLesson2Start1.Location = new Point(514, 125);
            tboxLesson2Start1.Name = "tboxLesson2Start1";
            tboxLesson2Start1.Size = new Size(75, 27);
            tboxLesson2Start1.TabIndex = 53;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(476, 295);
            label29.Name = "label29";
            label29.Size = new Size(20, 20);
            label29.TabIndex = 52;
            label29.Text = "6.";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(476, 328);
            label30.Name = "label30";
            label30.Size = new Size(20, 20);
            label30.TabIndex = 51;
            label30.Text = "7.";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(476, 262);
            label31.Name = "label31";
            label31.Size = new Size(20, 20);
            label31.TabIndex = 50;
            label31.Text = "5.";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(476, 196);
            label32.Name = "label32";
            label32.Size = new Size(20, 20);
            label32.TabIndex = 49;
            label32.Text = "3.";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(476, 229);
            label33.Name = "label33";
            label33.Size = new Size(20, 20);
            label33.TabIndex = 48;
            label33.Text = "4.";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(476, 161);
            label34.Name = "label34";
            label34.Size = new Size(20, 20);
            label34.TabIndex = 47;
            label34.Text = "2.";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(476, 128);
            label35.Name = "label35";
            label35.Size = new Size(20, 20);
            label35.TabIndex = 46;
            label35.Text = "1.";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label36.Location = new Point(589, 9);
            label36.Name = "label36";
            label36.Size = new Size(151, 32);
            label36.TabIndex = 45;
            label36.Text = "Втора смяна";
            // 
            // cbox1Monday
            // 
            cbox1Monday.AutoSize = true;
            cbox1Monday.Checked = true;
            cbox1Monday.CheckState = CheckState.Checked;
            cbox1Monday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox1Monday.Location = new Point(19, 62);
            cbox1Monday.Name = "cbox1Monday";
            cbox1Monday.Size = new Size(64, 24);
            cbox1Monday.TabIndex = 84;
            cbox1Monday.Text = "ПОН";
            cbox1Monday.UseVisualStyleBackColor = true;
            // 
            // cbox1Tuesday
            // 
            cbox1Tuesday.AutoSize = true;
            cbox1Tuesday.Checked = true;
            cbox1Tuesday.CheckState = CheckState.Checked;
            cbox1Tuesday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox1Tuesday.Location = new Point(89, 62);
            cbox1Tuesday.Name = "cbox1Tuesday";
            cbox1Tuesday.Size = new Size(59, 24);
            cbox1Tuesday.TabIndex = 85;
            cbox1Tuesday.Text = "ВТО";
            cbox1Tuesday.UseVisualStyleBackColor = true;
            // 
            // cbox1Wednesday
            // 
            cbox1Wednesday.AutoSize = true;
            cbox1Wednesday.Checked = true;
            cbox1Wednesday.CheckState = CheckState.Checked;
            cbox1Wednesday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox1Wednesday.Location = new Point(162, 62);
            cbox1Wednesday.Name = "cbox1Wednesday";
            cbox1Wednesday.Size = new Size(59, 24);
            cbox1Wednesday.TabIndex = 86;
            cbox1Wednesday.Text = "СРЯ";
            cbox1Wednesday.UseVisualStyleBackColor = true;
            // 
            // cbox1Thursday
            // 
            cbox1Thursday.AutoSize = true;
            cbox1Thursday.Checked = true;
            cbox1Thursday.CheckState = CheckState.Checked;
            cbox1Thursday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox1Thursday.Location = new Point(243, 62);
            cbox1Thursday.Name = "cbox1Thursday";
            cbox1Thursday.Size = new Size(59, 24);
            cbox1Thursday.TabIndex = 87;
            cbox1Thursday.Text = "ЧЕТ";
            cbox1Thursday.UseVisualStyleBackColor = true;
            // 
            // cbox1Friday
            // 
            cbox1Friday.AutoSize = true;
            cbox1Friday.Checked = true;
            cbox1Friday.CheckState = CheckState.Checked;
            cbox1Friday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox1Friday.Location = new Point(323, 62);
            cbox1Friday.Name = "cbox1Friday";
            cbox1Friday.Size = new Size(59, 24);
            cbox1Friday.TabIndex = 88;
            cbox1Friday.Text = "ПЕТ";
            cbox1Friday.UseVisualStyleBackColor = true;
            // 
            // cbox2Friday
            // 
            cbox2Friday.AutoSize = true;
            cbox2Friday.Checked = true;
            cbox2Friday.CheckState = CheckState.Checked;
            cbox2Friday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox2Friday.Location = new Point(786, 62);
            cbox2Friday.Name = "cbox2Friday";
            cbox2Friday.Size = new Size(59, 24);
            cbox2Friday.TabIndex = 93;
            cbox2Friday.Text = "ПЕТ";
            cbox2Friday.UseVisualStyleBackColor = true;
            // 
            // cbox2Thursday
            // 
            cbox2Thursday.AutoSize = true;
            cbox2Thursday.Checked = true;
            cbox2Thursday.CheckState = CheckState.Checked;
            cbox2Thursday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox2Thursday.Location = new Point(706, 62);
            cbox2Thursday.Name = "cbox2Thursday";
            cbox2Thursday.Size = new Size(59, 24);
            cbox2Thursday.TabIndex = 92;
            cbox2Thursday.Text = "ЧЕТ";
            cbox2Thursday.UseVisualStyleBackColor = true;
            // 
            // cbox2Wednesday
            // 
            cbox2Wednesday.AutoSize = true;
            cbox2Wednesday.Checked = true;
            cbox2Wednesday.CheckState = CheckState.Checked;
            cbox2Wednesday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox2Wednesday.Location = new Point(625, 62);
            cbox2Wednesday.Name = "cbox2Wednesday";
            cbox2Wednesday.Size = new Size(59, 24);
            cbox2Wednesday.TabIndex = 91;
            cbox2Wednesday.Text = "СРЯ";
            cbox2Wednesday.UseVisualStyleBackColor = true;
            // 
            // cbox2Tuesday
            // 
            cbox2Tuesday.AutoSize = true;
            cbox2Tuesday.Checked = true;
            cbox2Tuesday.CheckState = CheckState.Checked;
            cbox2Tuesday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox2Tuesday.Location = new Point(552, 62);
            cbox2Tuesday.Name = "cbox2Tuesday";
            cbox2Tuesday.Size = new Size(59, 24);
            cbox2Tuesday.TabIndex = 90;
            cbox2Tuesday.Text = "ВТО";
            cbox2Tuesday.UseVisualStyleBackColor = true;
            // 
            // cbox2Monday
            // 
            cbox2Monday.AutoSize = true;
            cbox2Monday.Checked = true;
            cbox2Monday.CheckState = CheckState.Checked;
            cbox2Monday.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbox2Monday.Location = new Point(482, 62);
            cbox2Monday.Name = "cbox2Monday";
            cbox2Monday.Size = new Size(64, 24);
            cbox2Monday.TabIndex = 89;
            cbox2Monday.Text = "ПОН";
            cbox2Monday.UseVisualStyleBackColor = true;
            // 
            // toolTip1
            // 
            toolTip1.ForeColor = SystemColors.HotTrack;
            // 
            // btnGenerateTimeTable2
            // 
            btnGenerateTimeTable2.BackColor = SystemColors.ActiveCaption;
            btnGenerateTimeTable2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnGenerateTimeTable2.Location = new Point(515, 373);
            btnGenerateTimeTable2.Name = "btnGenerateTimeTable2";
            btnGenerateTimeTable2.Size = new Size(263, 72);
            btnGenerateTimeTable2.TabIndex = 94;
            btnGenerateTimeTable2.Text = "Генерирай разписание втора смяна";
            toolTip1.SetToolTip(btnGenerateTimeTable2, "За да генерирате разписание е нужно \r\nда въведете начало и край за първи час,\r\nкакто и всички междучасия.");
            btnGenerateTimeTable2.UseVisualStyleBackColor = false;
            btnGenerateTimeTable2.Click += btnGenerateTimeTable2_Click;
            // 
            // lblInfo
            // 
            lblInfo.BackColor = SystemColors.Control;
            lblInfo.Location = new Point(48, 460);
            lblInfo.Name = "lblInfo";
            lblInfo.Size = new Size(806, 132);
            lblInfo.TabIndex = 95;
            lblInfo.Text = "Info";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(980, 604);
            Controls.Add(lblInfo);
            Controls.Add(btnGenerateTimeTable2);
            Controls.Add(cbox2Friday);
            Controls.Add(cbox2Thursday);
            Controls.Add(cbox2Wednesday);
            Controls.Add(cbox2Tuesday);
            Controls.Add(cbox2Monday);
            Controls.Add(cbox1Friday);
            Controls.Add(cbox1Thursday);
            Controls.Add(cbox1Wednesday);
            Controls.Add(cbox1Tuesday);
            Controls.Add(cbox1Monday);
            Controls.Add(label19);
            Controls.Add(cbox2break7);
            Controls.Add(tboxLesson2End7);
            Controls.Add(tboxLesson2Start7);
            Controls.Add(label20);
            Controls.Add(cbox2break6);
            Controls.Add(tboxLesson2End6);
            Controls.Add(tboxLesson2Start6);
            Controls.Add(label21);
            Controls.Add(cbox2break5);
            Controls.Add(tboxLesson2End5);
            Controls.Add(tboxLesson2Start5);
            Controls.Add(label22);
            Controls.Add(cbox2break4);
            Controls.Add(tboxLesson2End4);
            Controls.Add(tboxLesson2Start4);
            Controls.Add(label23);
            Controls.Add(cbox2break3);
            Controls.Add(tboxLesson2End3);
            Controls.Add(tboxLesson2Start3);
            Controls.Add(label24);
            Controls.Add(cbox2break2);
            Controls.Add(tboxLesson2End2);
            Controls.Add(tboxLesson2Start2);
            Controls.Add(label25);
            Controls.Add(cbox2break1);
            Controls.Add(label26);
            Controls.Add(tboxLesson2End1);
            Controls.Add(label27);
            Controls.Add(label28);
            Controls.Add(tboxLesson2Start1);
            Controls.Add(label29);
            Controls.Add(label30);
            Controls.Add(label31);
            Controls.Add(label32);
            Controls.Add(label33);
            Controls.Add(label34);
            Controls.Add(label35);
            Controls.Add(label36);
            Controls.Add(btnGenerateTimeTable1);
            Controls.Add(label18);
            Controls.Add(cbox1break7);
            Controls.Add(tboxLesson1End7);
            Controls.Add(tboxLesson1Start7);
            Controls.Add(label17);
            Controls.Add(cbox1break6);
            Controls.Add(tboxLesson1End6);
            Controls.Add(tboxLesson1Start6);
            Controls.Add(label16);
            Controls.Add(cbox1break5);
            Controls.Add(tboxLesson1End5);
            Controls.Add(tboxLesson1Start5);
            Controls.Add(label15);
            Controls.Add(cbox1break4);
            Controls.Add(tboxLesson1End4);
            Controls.Add(tboxLesson1Start4);
            Controls.Add(label14);
            Controls.Add(cbox1break3);
            Controls.Add(tboxLesson1End3);
            Controls.Add(tboxLesson1Start3);
            Controls.Add(label13);
            Controls.Add(cbox1break2);
            Controls.Add(tboxLesson1End2);
            Controls.Add(tboxLesson1Start2);
            Controls.Add(label12);
            Controls.Add(cbox1break1);
            Controls.Add(label11);
            Controls.Add(tboxLesson1End1);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(tboxLesson1Start1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblClock);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Ring Bell PMG-GRE";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblClock;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox tboxLesson1Start1;
        private Label label9;
        private Label label10;
        private TextBox tboxLesson1End1;
        private Label label11;
        private ComboBox cbox1break1;
        private Label label12;
        private Label label13;
        private ComboBox cbox1break2;
        private TextBox tboxLesson1End2;
        private TextBox tboxLesson1Start2;
        private Label label14;
        private ComboBox cbox1break3;
        private TextBox tboxLesson1End3;
        private TextBox tboxLesson1Start3;
        private Label label15;
        private ComboBox cbox1break4;
        private TextBox tboxLesson1End4;
        private TextBox tboxLesson1Start4;
        private Label label16;
        private ComboBox cbox1break5;
        private TextBox tboxLesson1End5;
        private TextBox tboxLesson1Start5;
        private Label label17;
        private ComboBox cbox1break6;
        private TextBox tboxLesson1End6;
        private TextBox tboxLesson1Start6;
        private Label label18;
        private ComboBox cbox1break7;
        private TextBox tboxLesson1End7;
        private TextBox tboxLesson1Start7;
        private Button btnGenerateTimeTable1;
        private ErrorProvider errorProvider1;
        private Label label19;
        private ComboBox cbox2break7;
        private TextBox tboxLesson2End7;
        private TextBox tboxLesson2Start7;
        private Label label20;
        private ComboBox cbox2break6;
        private TextBox tboxLesson2End6;
        private TextBox tboxLesson2Start6;
        private Label label21;
        private ComboBox cbox2break5;
        private TextBox tboxLesson2End5;
        private TextBox tboxLesson2Start5;
        private Label label22;
        private ComboBox cbox2break4;
        private TextBox tboxLesson2End4;
        private TextBox tboxLesson2Start4;
        private Label label23;
        private ComboBox cbox2break3;
        private TextBox tboxLesson2End3;
        private TextBox tboxLesson2Start3;
        private Label label24;
        private ComboBox cbox2break2;
        private TextBox tboxLesson2End2;
        private TextBox tboxLesson2Start2;
        private Label label25;
        private ComboBox cbox2break1;
        private Label label26;
        private TextBox tboxLesson2End1;
        private Label label27;
        private Label label28;
        private TextBox tboxLesson2Start1;
        private Label label29;
        private Label label30;
        private Label label31;
        private Label label32;
        private Label label33;
        private Label label34;
        private Label label35;
        private Label label36;
        private CheckBox cbox1Wednesday;
        private CheckBox cbox1Tuesday;
        private CheckBox cbox1Monday;
        private CheckBox cbox1Friday;
        private CheckBox cbox1Thursday;
        private CheckBox cbox2Friday;
        private CheckBox cbox2Thursday;
        private CheckBox cbox2Wednesday;
        private CheckBox cbox2Tuesday;
        private CheckBox cbox2Monday;
        private ToolTip toolTip1;
        private Button btnGenerateTimeTable2;
        private Label lblInfo;
    }
}
