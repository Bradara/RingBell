﻿namespace RingBell
{
    internal class Shift
    {
        public int ID { get; set; }
        public string? Name { get; set; }
        public int StartHour { get; set; }
        public int StartMinutes { get; set; }
    }
}
